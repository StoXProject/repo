#!/bin/bash

# Set path to fix Rtools 4.0 in Appveyor
#PATH=/usr/bin:$PATH

set -o errexit -o nounset
cd ..

addToDrat(){
  mkdir drat; cd drat

  ## Set up Repo parameters
  git init
  git config user.name "StoXProject bot"
  git config user.email "stox@hi.no"
  git config --global push.default simple

  ## Get drat repo
  git remote add upstream "https://x-access-token:${DRAT_DEPLOY_TOKEN}@github.com/StoXProject/repo.git"

  git fetch upstream 2>err.txt
  git checkout gh-pages

  Rscript -e "library(drat); insertPackage('$PKG_REPO/$PKG_FILE', \
    repodir = '.', \
    commit='Repo update $PKG_REPO: build $BUILD_NUMBER')"
  git push 2>err.txt

  cd $PKG_REPO
}

addToDrat

