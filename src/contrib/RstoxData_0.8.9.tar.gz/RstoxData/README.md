# RstoxData version: 0.6.7 (latest alpha, 2020-03-20)
## R version: 3.5

[![Build Status](https://travis-ci.org/StoXProject/RstoxData.svg?branch=master)](https://travis-ci.org/StoXProject/RstoxData)
[![Build status](https://ci.appveyor.com/api/projects/status/wcoo0w1syffu2yw3?svg=true)](https://ci.appveyor.com/project/iambaim/rstoxdata)

Tools to fetch and manipulate various data formats for fisheries (mainly geared towards biotic and acoustic data).


### Install the latest developer version
devtools::install_github("StoXProject/RstoxData")


### Release notes for RstoxData_0.6.7

