/*!
  \file caa.c
  \brief global variables
*/
#include "caa.h"

FILE *g_caa_log;
FILE *g_caa_alpha;
 
FILE *g_caa_mcmc1;
FILE *g_caa_mcmc2;
FILE *g_caa_mcmc_hsz;
FILE *g_caa_mcmc_hsz_eff;

