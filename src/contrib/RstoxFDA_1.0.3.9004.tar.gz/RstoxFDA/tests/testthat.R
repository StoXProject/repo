library(testthat)
library(RstoxFDA)
library(RstoxData)
test_check("RstoxFDA")
