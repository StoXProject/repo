# RstoxData v1.0.15 (2019-10-162019-10-16)

* Created the package, which will be a library for StoX functions used for survey estimation, including defining resolution and calculating density, abundance and super individual data.
