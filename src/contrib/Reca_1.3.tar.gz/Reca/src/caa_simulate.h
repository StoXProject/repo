#ifndef CAA_SIMULATE_H_INCLUDED_
#define CAA_SIMULATE_H_INCLUDED_

int Simulate_length_weight(Age_struct *i_age,Data_age *i_D_age,
			   LW_struct *i_length,Data_lin *o_D_length_sim,
			   LW_struct *i_weight,Data_lin *o_D_weight_sim);

#endif // include guard
