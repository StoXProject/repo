int main_model1(Input_common *i_inCommon, Input_age *i_inAge, Input_lga *i_inLga, 
		Input_wgl *i_inHsz, Input_prior *i_inPrior, Data_orig *i_D_orig, 
		Data_CC *i_D_CC);
int main_model2(Input_common *i_inCommon, Input_wgl *i_inWgl,
		Input_prior *i_inPrior, Data_orig *i_D_orig, int i_hsz);
int main_model_hsz(Input_common *i_inCommon,Input_wgl *i_inHsz,Input_prior *i_inPrior,Data_orig *i_D_orig);
