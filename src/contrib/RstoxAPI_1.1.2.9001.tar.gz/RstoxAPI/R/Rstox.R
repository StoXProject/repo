##################################################
##################################################
#' Definitions stored in the RstoxFramework environment
#' 
#' This function declares the RstoxFramework environment and writes vital definitions to it.
#' 
#' @return
#' A list of definitions.
#' 
#' @noRd
#' @seealso Use \code{\link{getRstoxFrameworkDefinitions}} to get the definitions.
#' 
initiateRstoxAPI <- function(){
    
    # Define versions of the packcages constituting official releases:
    RstoxVersions <- list(
        
        # Version 1.0:
        "1.0" = data.table::data.table(
            packageName = c(
                "RstoxFramework",
                "RstoxBase",
                "RstoxData"
            ), 
            version = c(
                "1.1", 
                "1.1", 
                "0.7" 
            ), 
            onCRAN = c(
                FALSE, 
                FALSE, 
                FALSE
            )
        )
        
    )
    
    #### Assign to RstoxEnv and return the definitions: ####
    definitionsNames <- ls()
    definitions <- lapply(definitionsNames, get, pos = environment())
    names(definitions) <- definitionsNames
    
    #### Create the RstoxFrameworkEnv environment, holding definitions on folder structure and all the projects. This environment cna be accesses using RstoxFramework:::RstoxFrameworkEnv: ####
    utils::globalVariables("RstoxAPIEnv")
    assign("RstoxAPIEnv", new.env(), parent.env(environment()))
    
    assign("definitions", definitions, envir=get("RstoxAPIEnv"))
    
    # Load RstoxFramework, so that is is added in the search path and available in runFunction():
    library(RstoxFramework)
    
    #### Return the definitions: ####
    definitions
}


##################################################
##################################################
#' Get RstoxAPI definitions
#' 
#' This function gets vital definitions from the RstoxAPI environment.
#' 
#' @param name  An optional string vector denoting which definitions to extract.
#' 
#' @return
#' A list of definitions.
#' 
#' @examples
#' getRstoxAPIDefinitions()
#' 
#' @noRd
#' 
getRstoxAPIDefinitions <- function(name = NULL) {
    
    # Get all or a subset of the definitions:
    definitions <- get("RstoxAPIEnv")$definitions
    if(length(name)){
        definitions <- definitions[[name]]
    }

    definitions
}


##################################################
##################################################
#' Run a model of a StoX project
#' 
#' This function runs and returns output from a model of a StoX project.
#' 
#' @param projectPath       The path to the StoX project, i.e., the folder of the project with the sub folders "input", "output" and "process". Can possibly be the path to a file inside the project folder.
#' @param modelName         xx
#' @param startProcess      xx
#' @param endProcess        Integer value speicfying the 
#' @param run               Logical: If TRUE run the model.
#' @param save              Logical: If TRUE save the project after running.
#' @param force.restart     Logical: If TRUE restart the model before running.
#' 
#' @return
#' A list of model output.
#' 
#' 
#' @export
#' 
runModel <- function(projectPath, modelName, startProcess = 1, endProcess = Inf, run = TRUE, save = TRUE, force.restart = FALSE) {
    # Run the model if required:
    if(run) {
        RstoxFramework::runProcesses(
            projectPath = projectPath, 
            modelName = modelName, 
            startProcess = startProcess, 
            endProcess = endProcess, 
            save = save, 
            force.restart = force.restart
        )
    }
    # Get the model data:
    modelData <- RstoxFramework::getModelData(
        projectPath = projectPath, 
        modelName = modelName, 
        startProcess = startProcess, 
        endProcess = endProcess
    )
    
    return(modelData)
}


#' 
#' @export
#' 
runFunction <- function(what, args, package = "RstoxFramework", removeCall = TRUE, onlyStoxMessages = TRUE) {
    
    # Parse the args if given as a JSON string:
    args <- RstoxFramework::parseParameter(args)
    
    # Reset the warnings:
    assign("last.warning", NULL, envir = baseenv())
    
    # Run the function 'what' and store the warnings and error along with the result:
    warn <- character(0)
    err <- NULL
    msg <- capture.output({
        value <- withCallingHandlers(
            tryCatch(
                #do.call(what, args), 
                do.call(getExportedValue(package, what), args), 
                error = function(e) {
                    err <<- if(removeCall) conditionMessage(e) else e
                    NULL
                }
            ), 
            warning=function(w) {
                warn <<- append(warn, if(removeCall) conditionMessage(w) else w)
                invokeRestart("muffleWarning")
            }
        )
    }, type = "message")
    
    if(length(warn)) {
        warn <- as.character(warn)
    }
    if(length(err)) {
        err <- as.character(err)
    }
    if(onlyStoxMessages) {
        msg <- trimws(sub("StoX:", "", msg[startsWith(msg, "StoX:")], fixed = TRUE))
    }
    
    
    # Clean the warnings:
    #warn <- unname(unlist(warn[names(warn) == "message"]))
    
    # Return a list of warnings and error along with the result:
    list(
        #value = if(!is.list(value)) as.list(value) else value, 
        value = value, 
        message = as.list(msg), 
        warning = as.list(warn), 
        error = as.list(err)
    )
}


installRstoxPackages <- function(version) {
    # Get the versions to install:
    versions <- getRstoxVersions(version)
    
    # Check that the packages listed here are the same that are specified in RstoxFramework:
    functionsPackages <- RstoxFramework::getRstoxFrameworkDefinitions("officialStoxLibraryPackages")
    allPresent <- identical(
        sort(
            names(
                versions
            )
        ), 
        sort(
            c(
                "RstoxFramework", 
                functionsPackages
            )
        )
    )
    if(!allPresent) {
        stop("The packages listed in RstoxVersions are not all present in the list of packages in RstoxFramework.")
    }
    
    # Uninstall the packages and then install the correct versions:
    mapply(
        uninstallAndInstall, 
        packageName = versions$packageName, 
        version = versions$version, 
        onCRAN = versions$onCRAN
    )
    
}

uninstallAndInstall <- function(packageName, version, onCRAN = FALSE) {
    
    # Remove the package from all libraries:
    try(lapply(.libPaths(), function(x) utils::remove.packages(packageName, x)), silent = TRUE)
    
    # Install the package version:
    if(onCRAN) {
        devtools::install_version(packageName, version = version, repos = "http://cran.us.r-project.org")
    }
    # On github the "v" is added to the version:
    else {
        ref <- paste0("v", version)
        devtools::install_github(packageName, ref = ref)
    }
}



# Function for map one process from StoX 2.7 to StoX 3.0:
mapProcess2.7To3.0 <- function(projectDescription) {
    
    # First move the models of the old StoX ("baseline", "baseline-report", "r", "r-report") to the models of the new (baseline, report analysis, report):
    modelNameMap <- list(
        baseline = c("baseline"), 
        analysis = c("r"), 
        report = c("baseline-report", "r-report")
    )
    
    mappedProjectDescription <- lapply(
        modelNameMap, 
        function(x) unlist(projectDescription[x], recursive = FALSE)
    )
    newProjectDescription <- structure(rep(list(list()), length(modelNameMap)), names = names(modelNameMap))
    
    # Then loop through the models and map the processes:
    for(model in names(mappedProjectDescription)) {
        for(processName in names(mappedProjectDescription[[model]])) {
            
            # (1) Add process name:
            newProjectDescription[[model]][[processName]]$processName <- processName
            
            # (2) Add function name:
            newProjectDescription[[model]][[processName]]$functionName <- mappedProjectDescription[[model]][[processName]][["function"]]
            
            # (3) Add process parameters:
            newProjectDescription[[model]][[processName]]$processParameters$enabled <- mappedProjectDescription[[model]][[processName]]$enabled
            newProjectDescription[[model]][[processName]]$processParameters$showInMap <- mappedProjectDescription[[model]][[processName]]$enabled
            newProjectDescription[[model]][[processName]]$processParameters$fileOutput <- mappedProjectDescription[[model]][[processName]]$enabled
            
            # (4) Add process name:
            newProjectDescription[[model]][[processName]]$processName <- processName
            
            # (5) Add process name:
            newProjectDescription[[model]][[processName]]$processName <- processName
            
            # (6) Add process name:
            newProjectDescription[[model]][[processName]]$processName <- processName
        }
    }
    
    # Declare the process in StoX 3.0:
    newProcess <- list()
    
    # Insert the process name:
    newProcess$processName <- 333333333333
    
}


