library(testthat)
library(RstoxFramework)

# We have currently three test projects:
options(Ncpus = 4L)

test_check("RstoxFramework")