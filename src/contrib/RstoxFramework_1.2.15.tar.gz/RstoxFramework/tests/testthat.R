library(testthat)
library(RstoxFramework)

test_check("RstoxFramework")