.onLoad <- function(libname, pkgname){
	# Initiate the RstoxData environment:
	initiateRstoxData()
} 
