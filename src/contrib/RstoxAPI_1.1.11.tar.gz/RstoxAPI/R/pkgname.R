#' The API to StoX
#'
#' This package is the interface between RstoxFramework and the StoX GUI. It ensures that the specified packages are installed for a StoX version.
#'
#' The package contains the function runModel() for running a model of a StoX project, runFunction() for accessing a function in RstoxFramework (or another package), and specifies the particular versions of the RstoxFramework and the packages specified as official packages by RstoxFramework.
#' @docType package
#' @name RstoxAPI
#'
"_PACKAGE"

.onLoad <- function(libname, pkgname) {
	# Initiate the RstoxAPI environment:
	initiateRstoxAPI()
} 

