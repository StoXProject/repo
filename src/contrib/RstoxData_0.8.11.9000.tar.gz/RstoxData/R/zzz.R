# Set local package extdata location
#utils::globalVariables(c("xsdObjects", "localEnv", ":=") )
utils::globalVariables(c("xsdObjects", ":=") )
