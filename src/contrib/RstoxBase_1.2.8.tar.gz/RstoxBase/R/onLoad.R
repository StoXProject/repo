.onLoad <- function(libname, pkgname){
	# Initiate the RstoxBase environment:
	initiateRstoxBase()
} 
