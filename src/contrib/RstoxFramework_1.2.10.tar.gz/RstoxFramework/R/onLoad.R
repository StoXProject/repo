.onLoad <- function(libname, pkgname){
	# Initiate the RstoxFramework environment:
	initiateRstoxFramework()
} 
