## ----include, include=FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, include=FALSE-----------------------------------------------------
library(RstoxFDA)

## ----docfunction, echo=TRUE---------------------------------------------------
?RstoxFDA::RunRecaModels

## ----docformat, echo=TRUE-----------------------------------------------------
?RstoxFDA::RecaData

