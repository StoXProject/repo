library(testthat)

test_check("RstoxBase")
