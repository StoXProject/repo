library(testthat)
library(RstoxFramework)

# We have currently three test projects:
options(Ncpus = 3L)

test_check("RstoxFramework")