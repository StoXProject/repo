#ifndef CAA_SUMMARIES_H_INCLUDED_
#define CAA_SUMMARIES_H_INCLUDED_

int summaries_init(int i_ncat);
int summaries_re_init();
int calc_summaries(int i_start_h,Age_struct *i_age,Data_age *i_D_age,Data_g_a *i_D_g_a,
		   LW_struct *i_length,Data_lin *i_D_lga,Data_l *i_D_l);

#endif // include guard
