.onLoad <- function(libname, pkgname){
	# Initiate the RstoxAPI environment:
	initiateRstoxAPI()
} 
