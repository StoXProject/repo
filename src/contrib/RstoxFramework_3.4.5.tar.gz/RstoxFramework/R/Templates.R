stoxTemplates <- list(
	#### UserDefined Template: User defined (empty models): ####
	EmptyTemplate = structure(
		list(), 
		description = "User defined (empty models)"
	)
)