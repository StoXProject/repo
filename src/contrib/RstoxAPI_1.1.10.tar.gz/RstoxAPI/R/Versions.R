#RstoxVersions <- list(
#    
#    # Version 1.0:
#    "1.0" = data.table::data.table(
#        packageName = c(
#            "RstoxFramework",
#            "RstoxBase",
#            "RstoxData"
#        ), 
#        version = c(
#            "1.1", 
#            "1.1", 
#            "0.7" 
#        ), 
#        onCRAN = c(
#            FALSE, 
#            FALSE, 
#            FALSE
#        )
#    )
#    
#)


##################################################
##################################################
#' Get RstoxAPI version
#' 
#' This function declares the RstoxFramework environment and writes vital definitions to it.
#' 
#' @return
#' A list of definitions.
#' 
#' @noRd
#' @seealso Use \code{\link{getRstoxFrameworkDefinitions}} to get the definitions.
#' 
#' 
#' @export
#'
getRstoxAPIVersion <- function() {
    as.character(packageVersion("RstoxAPI"))
}

#' 
#' @export
#'
getInstalledRstoxVersions <- function() {
    # Get the RstoxAPI version:
    RstoxAPIVersion <- getRstoxAPIVersion()
    # Get the installed versions of the dependent Rstox packages:
    RstoxPackages <- getOfficialRstoxVersions()$packageName
    installedRstoxPackages <- sapply(RstoxPackages, function(x) as.character(utils::packageVersion(x)), simplify = FALSE)
    
    packageVersions <- c(
        list(RstoxAPI = RstoxAPIVersion), 
        installedRstoxPackages
    )
    
    return(packageVersions)
}

#' 
#' @export
#'
getOfficialRstoxVersions <- function() {
    RstoxVersions <- getRstoxAPIDefinitions("RstoxVersions")
    atVersion <- which(names(RstoxVersions) == getRstoxAPIVersion())
    if(length(atVersion) == 0) {
        stop("The current RstoxAPI version ", getRstoxAPIVersion(), " is not present in the list RstoxVersions (the following versions are present: ", paste(names(RstoxVersions), collapse = ", "), ")")
    }
    output <- RstoxVersions[[atVersion]]
    return(output)
}




##################################################
##################################################
#' Export StoX JSON schema
#' 
#' @param con A connection to which to write the schema. Returned as JSON if missing.
#' 
#' @export
#' 
getStoxJsonSchema <- function(con) {
    schema <- RstoxFramework::getRstoxFrameworkDefinitions("schema")
    if(missing(con)) {
        return(schema)
    }
    else {
        writeLines(as.character(schema), con)
    }
}


